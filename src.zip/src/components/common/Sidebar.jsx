import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  FiGrid,
  FiPlusCircle,
  FiList,
  FiPackage,
  FiSearch,
  FiDollarSign,
  FiTrendingDown,
  FiUsers,
} from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';

const Sidebar = ({ isOpen }) => {
  const { user } = useAuth();
  const isOwnerOrKasir = user && ['owner', 'kasir'].includes(user.role);

  return (
    <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-brand">🧺 Smart Laundry</div>

      <nav className="sidebar-nav">
        {isOwnerOrKasir && (
          <>
            <p className="sidebar-section-title">Menu Utama</p>
            <NavLink to="/dashboard" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              <FiGrid /> Dashboard
            </NavLink>

            <p className="sidebar-section-title">Transaksi</p>
            <NavLink to="/transaksi/baru" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              <FiPlusCircle /> Transaksi Baru
            </NavLink>
            <NavLink to="/transaksi" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              <FiList /> Daftar Transaksi
            </NavLink>

            <p className="sidebar-section-title">Layanan</p>
            <NavLink to="/layanan" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              <FiPackage /> Kelola Layanan
            </NavLink>

            <p className="sidebar-section-title">Pelanggan</p>
            <NavLink to="/pelanggan" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              <FiUsers /> Daftar Pelanggan
            </NavLink>

            <p className="sidebar-section-title">Keuangan</p>
            <NavLink to="/keuangan/laporan" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              <FiDollarSign /> Laporan Keuangan
            </NavLink>
            <NavLink to="/keuangan/pengeluaran" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
              <FiTrendingDown /> Kelola Pengeluaran
            </NavLink>
          </>
        )}

        <p className="sidebar-section-title">Lacak Cucian</p>
        <NavLink to="/cek-status" className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
          <FiSearch /> Cek Status
        </NavLink>
      </nav>
    </aside>
  );
};

export default Sidebar;
