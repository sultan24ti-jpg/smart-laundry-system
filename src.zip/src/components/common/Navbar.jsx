import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FiMenu, FiLogOut } from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';

const Navbar = ({ onToggleSidebar }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const initial = user?.nama ? user.nama.charAt(0).toUpperCase() : '?';

  return (
    <div className="navbar">
      <button className="navbar-toggle" onClick={onToggleSidebar} aria-label="Toggle menu">
        <FiMenu />
      </button>

      <div />

      {user ? (
        <div className="navbar-user">
          <div className="navbar-avatar">{initial}</div>
          <div>
            <div style={{ fontWeight: 600 }}>{user.nama}</div>
            <div className="text-muted" style={{ fontSize: '12px', textTransform: 'capitalize' }}>
              {user.role}
            </div>
          </div>
          <button className="btn btn-secondary btn-sm" onClick={handleLogout} title="Keluar">
            <FiLogOut />
          </button>
        </div>
      ) : (
        <div />
      )}
    </div>
  );
};

export default Navbar;
