import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiSearch, FiEye, FiTrash2, FiPlus, FiPackage } from 'react-icons/fi';
import { getAllTransaksi, deleteTransaksi, STATUS_LABELS } from '../../services/database';
import { formatCurrency, formatDateTime, getStatusBadgeClass } from '../../utils/helpers';
import { useToast } from '../common/Toast';

const DaftarTransaksi = () => {
  const toast = useToast();
  const [transaksi, setTransaksi] = useState([]);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    load();
  }, []);

  const load = async () => setTransaksi(await getAllTransaksi());

  const handleDelete = async (id, kode) => {
    if (window.confirm(`Hapus transaksi ${kode}?`)) {
      try {
        await deleteTransaksi(id);
        toast.success('Transaksi berhasil dihapus');
        load();
      } catch (err) {
        toast.error(err.message || 'Gagal menghapus transaksi');
      }
    }
  };

  const filtered = transaksi.filter((t) => {
    const matchSearch =
      t.kode.toLowerCase().includes(search.toLowerCase()) ||
      t.pelangganNama.toLowerCase().includes(search.toLowerCase());
    const matchStatus = !filterStatus || t.status === filterStatus;
    return matchSearch && matchStatus;
  });

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Daftar Transaksi</h1>
          <p className="page-subtitle">{transaksi.length} total transaksi</p>
        </div>
        <Link to="/transaksi/baru" className="btn btn-primary"><FiPlus /> Transaksi Baru</Link>
      </div>

      <div className="card">
        <div className="flex gap-2" style={{ marginBottom: '20px', flexWrap: 'wrap' }}>
          <div className="search-bar">
            <FiSearch />
            <input
              type="text"
              placeholder="Cari kode atau nama pelanggan..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select className="form-select" style={{ maxWidth: '200px' }} value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
            <option value="">Semua Status</option>
            {Object.entries(STATUS_LABELS).map(([key, label]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
        </div>

        {filtered.length === 0 ? (
          <div className="empty-state">
            <FiPackage size={40} />
            <p>Tidak ada transaksi ditemukan.</p>
          </div>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Kode</th>
                  <th>Pelanggan</th>
                  <th>Tanggal</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((t) => (
                  <tr key={t.id}>
                    <td className="text-bold">{t.kode}</td>
                    <td>
                      {t.pelangganNama}
                      <div className="text-muted" style={{ fontSize: '12px' }}>{t.pelangganNohp}</div>
                    </td>
                    <td>{formatDateTime(t.createdAt)}</td>
                    <td>{formatCurrency(t.total)}</td>
                    <td><span className={getStatusBadgeClass(t.status)}>{STATUS_LABELS[t.status]}</span></td>
                    <td>
                      <div className="flex gap-1">
                        <button className="btn btn-secondary btn-sm" onClick={() => setSelected(t)}>
                          <FiEye />
                        </button>
                        <button className="btn btn-danger btn-sm" onClick={() => handleDelete(t.id, t.kode)}>
                          <FiTrash2 />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Detail Transaksi {selected.kode}</h3>
              <button className="modal-close" onClick={() => setSelected(null)}>&times;</button>
            </div>
            <div className="modal-body">
              <p><strong>Pelanggan:</strong> {selected.pelangganNama} ({selected.pelangganNohp})</p>
              <p><strong>Status:</strong> <span className={getStatusBadgeClass(selected.status)}>{STATUS_LABELS[selected.status]}</span></p>
              <p><strong>Estimasi Selesai:</strong> {formatDateTime(selected.estimasiSelesai)}</p>
              {selected.catatan && <p><strong>Catatan:</strong> {selected.catatan}</p>}

              <table style={{ marginTop: '16px' }}>
                <thead>
                  <tr><th>Layanan</th><th>Qty</th><th>Subtotal</th></tr>
                </thead>
                <tbody>
                  {selected.items.map((it, i) => (
                    <tr key={i}>
                      <td>{it.namaLayanan}</td>
                      <td>{it.qty} {it.satuan}</td>
                      <td>{formatCurrency(it.subtotal)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="flex-between mt-2">
                <strong>Total</strong>
                <strong>{formatCurrency(selected.total)}</strong>
              </div>
            </div>
            <div className="modal-footer">
              <Link to={`/transaksi/${selected.id}/status`} className="btn btn-primary">
                Update Status
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DaftarTransaksi;
