import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getDashboardStats, STATUS_LABELS } from '../../services/database';
import { formatCurrency, formatDateTime, getStatusBadgeClass } from '../../utils/helpers';
import {
  FiUsers,
  FiShoppingBag,
  FiDollarSign,
  FiTrendingUp,
  FiLoader,
  FiPlus,
} from 'react-icons/fi';

const DashboardOwner = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    try {
      const data = await getDashboardStats();
      setStats(data);
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  if (loading || !stats) {
    return (
      <div style={{ textAlign: 'center', padding: '48px' }}>
        <FiLoader className="spin" size={32} />
        <p style={{ marginTop: '16px', color: 'var(--gray-500)' }}>Memuat data...</p>
      </div>
    );
  }

  const statusColors = {
    diterima: 'yellow',
    proses: 'blue',
    siap_diambil: 'green',
    selesai: 'red',
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">Ringkasan operasional laundry hari ini</p>
        </div>
        <Link to="/transaksi/baru" className="btn btn-primary">
          <FiPlus /> Transaksi Baru
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-card-icon blue"><FiUsers /></div>
          <div className="stat-card-value">{stats.totalPelanggan}</div>
          <div className="stat-card-label">Total Pelanggan</div>
        </div>

        <div className="stat-card">
          <div className="stat-card-icon green"><FiShoppingBag /></div>
          <div className="stat-card-value">{stats.transaksiHariIni}</div>
          <div className="stat-card-label">Transaksi Hari Ini</div>
        </div>

        <div className="stat-card">
          <div className="stat-card-icon yellow"><FiDollarSign /></div>
          <div className="stat-card-value">{formatCurrency(stats.pendapatanHariIni)}</div>
          <div className="stat-card-label">Pendapatan Hari Ini</div>
        </div>

        <div className="stat-card">
          <div className="stat-card-icon red"><FiTrendingUp /></div>
          <div className="stat-card-value">{formatCurrency(stats.pendapatanBulanIni)}</div>
          <div className="stat-card-label">Pendapatan Bulan Ini</div>
        </div>
      </div>

      {/* Status Summary & Recent Transactions */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '24px' }} className="dashboard-grid">
        {/* Status Summary */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Status Cucian</h3>
          </div>
          {Object.entries(stats.statusCount).map(([status, count]) => (
            <div key={status} className="flex-between" style={{ marginBottom: '14px' }}>
              <div className="flex gap-1" style={{ alignItems: 'center' }}>
                <span className={`stat-card-icon ${statusColors[status]}`} style={{ width: '28px', height: '28px', fontSize: '12px' }}>
                  {count}
                </span>
                <span>{STATUS_LABELS[status]}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Recent Transactions */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Transaksi Terbaru</h3>
            <Link to="/transaksi" className="btn btn-secondary btn-sm">Lihat Semua</Link>
          </div>
          {stats.transaksiTerbaru.length === 0 ? (
            <div className="empty-state">
              <p>Belum ada transaksi.</p>
            </div>
          ) : (
            <div className="table-wrapper">
              <table>
                <thead>
                  <tr>
                    <th>Kode</th>
                    <th>Pelanggan</th>
                    <th>Tanggal</th>
                    <th>Total</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.transaksiTerbaru.map((t) => (
                    <tr key={t.id}>
                      <td className="text-bold">{t.kode}</td>
                      <td>{t.pelangganNama}</td>
                      <td>{formatDateTime(t.createdAt)}</td>
                      <td>{formatCurrency(t.total)}</td>
                      <td><span className={getStatusBadgeClass(t.status)}>{STATUS_LABELS[t.status]}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardOwner;
