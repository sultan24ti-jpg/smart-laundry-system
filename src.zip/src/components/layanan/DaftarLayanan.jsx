import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiPackage } from 'react-icons/fi';
import { getLayananAktif } from '../../services/database';
import { formatCurrency } from '../../utils/helpers';

// Halaman publik untuk menampilkan daftar layanan yang tersedia
const DaftarLayanan = () => {
  const [layanan, setLayanan] = useState([]);

  useEffect(() => {
    getLayananAktif().then(setLayanan);
  }, []);

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Daftar Layanan</h1>
          <p className="page-subtitle">Layanan laundry yang tersedia</p>
        </div>
      </div>

      {layanan.length === 0 ? (
        <div className="empty-state">
          <FiPackage size={40} />
          <p>Belum ada layanan tersedia.</p>
        </div>
      ) : (
        <div className="stats-grid">
          {layanan.map((l) => (
            <div key={l.id} className="card" style={{ marginBottom: 0 }}>
              <div className="stat-card-icon blue"><FiPackage /></div>
              <h4>{l.nama}</h4>
              <p className="text-muted">per {l.satuan}</p>
              <h3 style={{ color: 'var(--primary)', marginTop: '8px' }}>{formatCurrency(l.harga)}</h3>
              <p className="text-muted mt-1" style={{ fontSize: '13px' }}>Estimasi {l.durasiHari} hari</p>
            </div>
          ))}
        </div>
      )}

      <Link to="/transaksi/baru" className="btn btn-primary">Buat Transaksi</Link>
    </div>
  );
};

export default DaftarLayanan;
